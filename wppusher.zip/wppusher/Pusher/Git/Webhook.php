<?php

namespace Pusher\Git;

interface Webhook
{
    public function getRepository();
}
