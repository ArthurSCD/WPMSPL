<?php

namespace Pusher\Git;

use Exception;

class BitbucketWebhook implements Webhook
{
    protected $payload;

    public function __construct($payload)
    {
        $this->payload = $payload;
    }

    public function getRepository()
    {
        if ( ! isset($this->payload['repository']['full_name']))
            throw new Exception('Repository not found.');

        $handle = $this->payload['repository']['full_name'];

        return new BitbucketRepository($handle);
    }
}
