<?php
/**
 * Do not put custom translations here. They will be deleted on 'Multisite Toolbar Additions' updates!
 *
 * Keep custom 'Multisite Toolbar Additions' translations in '/wp-content/languages/multisite-toolbar-additions/'
 */
